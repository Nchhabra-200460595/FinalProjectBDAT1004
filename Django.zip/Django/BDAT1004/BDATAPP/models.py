from django.db import models


class Data(models.Model):
    platforms = models.TextField(db_column='Platforms', blank=True, null=True)  # Field name made lowercase.
    metric = models.TextField(db_column='Metric', blank=True, null=True)  # Field name made lowercase.
    year2017 = models.BigIntegerField(db_column='Year2017', blank=True, null=True)  # Field name made lowercase.
    year2018 = models.TextField(db_column='Year2018', blank=True, null=True)  # Field name made lowercase.
    year2019 = models.TextField(db_column='Year2019', blank=True, null=True)  # Field name made lowercase.
    year2020 = models.TextField(db_column='Year2020', blank=True, null=True)  # Field name made lowercase.
    id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DATA'